import { buildApp } from './server.js';

const port = Number(process.env.PORT || 3000);
const demo = process.env.NEXA_DEMO === '1';
buildApp().listen(port, '0.0.0.0', () => {
  console.log(`NEXA backend sur http://0.0.0.0:${port}${demo ? '  (mode DÉMO : profils simulés activés)' : ''}`);
});
