import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { openDb } from './db.js';
import { questions } from './questions.js';
import {
  buildTraits, computeMatch, isComplete, validateAnswers, demoAnswerSets,
  DEMO_NAMES, DEMO_CITIES, MATCH_THRESHOLD,
} from './engine.js';

export const FREE_MESSAGES = 50;
export const FREE_VISIBLE = 3;
const FREE_LIMIT = 5;
const PREMIUM_LIMIT = 20;
const DEMO_REPLIES = ['Salut ! NEXA nous a rapprochés 😊', 'Haha, raconte-moi plus !', 'Moi aussi, j\'adore ça.', 'On devrait se parler de vive voix bientôt.', 'Quelle est ta ville préférée en Tunisie ?'];

class HttpError extends Error {
  constructor(status, message, extra = {}) { super(message); this.status = status; this.extra = extra; }
}
const bad = (m) => new HttpError(400, m);

export function buildApp({ dbFile = process.env.NEXA_DB || 'data/nexa.db', demo = process.env.NEXA_DEMO === '1', fakePayment = process.env.NEXA_PAYMENT !== 'off', secret,
  threshold = Number(process.env.NEXA_THRESHOLD || MATCH_THRESHOLD), anyone = process.env.NEXA_ANYONE === '1' } = {}) {
  const db = openDb(dbFile);
  const SECRET = secret || process.env.NEXA_SECRET || (() => {
    if (dbFile === ':memory:') return crypto.randomBytes(32).toString('hex');
    const f = path.join(path.dirname(dbFile), 'secret.txt');
    if (!fs.existsSync(f)) fs.writeFileSync(f, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
    return fs.readFileSync(f, 'utf8');
  })();

  // ------------------------------------------------------------ helpers
  const q = (sql, ...p) => db.prepare(sql).all(...p);
  const one = (sql, ...p) => db.prepare(sql).get(...p);
  const run = (sql, ...p) => db.prepare(sql).run(...p);

  const b64 = (b) => Buffer.from(b).toString('base64url');
  const sign = (payload) => {
    const body = b64(JSON.stringify(payload));
    return `${body}.${crypto.createHmac('sha256', SECRET).update(body).digest('base64url')}`;
  };
  const verify = (token) => {
    const [body, sig] = (token || '').split('.');
    if (!body || !sig) return null;
    const exp = crypto.createHmac('sha256', SECRET).update(body).digest('base64url');
    const a = Buffer.from(sig), c = Buffer.from(exp);
    if (a.length !== c.length || !crypto.timingSafeEqual(a, c)) return null;
    const p = JSON.parse(Buffer.from(body, 'base64url').toString());
    return p.exp > Date.now() ? p : null;
  };
  const hashPw = (pw) => { const s = crypto.randomBytes(16); return `${s.toString('hex')}:${crypto.scryptSync(pw, s, 64).toString('hex')}`; };
  const checkPw = (pw, stored) => {
    const [s, h] = stored.split(':');
    const x = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64);
    return crypto.timingSafeEqual(x, Buffer.from(h, 'hex'));
  };

  const answersOf = (uid) => {
    const out = {};
    for (const r of q('SELECT question_id, selected FROM answers WHERE user_id = ?', uid)) out[r.question_id] = JSON.parse(r.selected);
    return out;
  };
  const notify = (uid, text) => run('INSERT INTO notifications (user_id, text) VALUES (?, ?)', uid, text);
  const pub = (u) => ({ id: u.id, name: u.name, age: u.age, city: u.city, bio: u.bio });
  const me_ = (u) => ({ ...pub(u), phone: u.phone, gender: u.gender, lookingFor: u.looking_for, premium: !!u.premium, completed: !!u.completed });
  const isBlocked = (a, b) => !!one('SELECT 1 x FROM blocks WHERE (user_id = ? AND blocked_id = ?) OR (user_id = ? AND blocked_id = ?)', a, b, b, a);

  /** Meilleures correspondances (>= 80 %, deal-breakers exclus), triées. */
  function matchesFor(me) {
    const myAns = answersOf(me.id);
    const wantGender = me.looking_for === 'Un homme' ? 'Homme' : 'Femme';
    const wantsMe = me.gender === 'Homme' ? 'Un homme' : 'Une femme';
    const rows = anyone
      ? q(`SELECT * FROM users WHERE id != ? AND completed = 1 AND is_demo = 0
          AND id NOT IN (SELECT blocked_id FROM blocks WHERE user_id = ?)
          AND id NOT IN (SELECT user_id FROM blocks WHERE blocked_id = ?)`, me.id, me.id, me.id)
      : q(`SELECT * FROM users WHERE id != ? AND gender = ? AND looking_for = ? AND completed = 1
          AND id NOT IN (SELECT blocked_id FROM blocks WHERE user_id = ?)
          AND id NOT IN (SELECT user_id FROM blocks WHERE blocked_id = ?)`, me.id, wantGender, wantsMe, me.id, me.id);
    const out = [];
    for (const u of rows) {
      const r = computeMatch(myAns, answersOf(u.id));
      if (r.blocks.length === 0 && r.score >= threshold) out.push({ user: u, ...r });
    }
    out.sort((a, b) => b.score - a.score);
    return out.slice(0, me.premium ? PREMIUM_LIMIT : FREE_LIMIT);
  }

  function spawnDemo(me) {
    const mine = answersOf(me.id);
    const gender = me.looking_for === 'Un homme' ? 'Homme' : 'Femme';
    const wants = me.gender === 'Homme' ? 'Un homme' : 'Une femme';
    if (one('SELECT COUNT(*) n FROM users WHERE demo_for = ?', me.id).n > 0) return 0;
    const sets = demoAnswerSets(mine, me.id);
    const ins = db.prepare(`INSERT INTO users (phone, pass_hash, name, age, city, gender, looking_for, bio, completed, is_demo, demo_for)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, ?)`);
    const insA = db.prepare('INSERT INTO answers (user_id, question_id, selected) VALUES (?, ?, ?)');
    let n = 0;
    sets.forEach((ans, i) => {
      const r = ins.run(`demo-${crypto.randomBytes(5).toString('hex')}`, hashPw(crypto.randomBytes(8).toString('hex')),
        DEMO_NAMES[gender][i], 24 + ((me.id + i * 3) % 10), DEMO_CITIES[(me.id + i) % DEMO_CITIES.length], gender, wants,
        'Profil de démonstration simulé.', me.id);
      for (const [qid, sel] of Object.entries(ans)) insA.run(r.lastInsertRowid, Number(qid), JSON.stringify(sel));
      n++;
    });
    return n;
  }

  function connectionFor(userId, connId) {
    const c = one('SELECT * FROM connections WHERE id = ?', connId);
    if (!c || (c.from_id !== userId && c.to_id !== userId)) throw new HttpError(404, 'Conversation introuvable');
    return c;
  }

  // ------------------------------------------------------------ routes
  const routes = [];
  const route = (method, pattern, handler, auth = true) =>
    routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler, auth });

  const hits = new Map();
  const limited = (ip) => {
    const now = Date.now();
    const arr = (hits.get(ip) || []).filter((t) => now - t < 60000);
    arr.push(now); hits.set(ip, arr);
    return arr.length > 20;
  };

  route('GET', '/health', () => ({ ok: true, demo, version: '0.1.0' }), false);

  route('POST', '/auth/register', ({ body, ip }) => {
    if (limited(ip)) throw new HttpError(429, 'Trop de tentatives, réessaie dans une minute');
    const { phone, password, name, age, city, gender, lookingFor } = body;
    if (!/^\+?[0-9]{8,15}$/.test(phone || '')) throw bad('Numéro de téléphone invalide');
    if (typeof password !== 'string' || password.length < 8) throw bad('Mot de passe : 8 caractères minimum');
    if (typeof name !== 'string' || !name.trim() || name.length > 40) throw bad('Prénom invalide');
    if (!Number.isInteger(age) || age < 18 || age > 99) throw bad('Âge invalide (18 ans minimum)');
    if (typeof city !== 'string' || !city.trim()) throw bad('Ville invalide');
    if (!['Femme', 'Homme'].includes(gender)) throw bad('Genre invalide');
    if (!['Un homme', 'Une femme'].includes(lookingFor)) throw bad('Recherche invalide');
    if (one('SELECT 1 x FROM users WHERE phone = ?', phone)) throw new HttpError(409, 'Ce numéro est déjà inscrit');
    // TODO production : vérification du numéro par SMS (OTP) avant activation du compte.
    const r = run('INSERT INTO users (phone, pass_hash, name, age, city, gender, looking_for) VALUES (?,?,?,?,?,?,?)',
      phone, hashPw(password), name.trim(), age, city.trim(), gender, lookingFor);
    const id = Number(r.lastInsertRowid);
    return [201, { token: sign({ uid: id, exp: Date.now() + 30 * 864e5 }), user: me_(one('SELECT * FROM users WHERE id = ?', id)) }];
  }, false);

  route('POST', '/auth/login', ({ body, ip }) => {
    if (limited(ip)) throw new HttpError(429, 'Trop de tentatives, réessaie dans une minute');
    const u = one('SELECT * FROM users WHERE phone = ? AND is_demo = 0', body.phone || '');
    if (!u || !checkPw(String(body.password || ''), u.pass_hash)) throw new HttpError(401, 'Identifiants incorrects');
    return { token: sign({ uid: u.id, exp: Date.now() + 30 * 864e5 }), user: me_(u) };
  }, false);

  route('GET', '/profile', ({ user }) => ({ user: me_(user), traits: user.completed ? buildTraits(answersOf(user.id)) : {} }));

  route('PUT', '/profile', ({ user, body }) => {
    const name = body.name ?? user.name, city = body.city ?? user.city, bio = body.bio ?? user.bio;
    const age = body.age ?? user.age;
    if (typeof name !== 'string' || !name.trim() || name.length > 40) throw bad('Prénom invalide');
    if (!Number.isInteger(age) || age < 18 || age > 99) throw bad('Âge invalide');
    if (typeof bio !== 'string' || bio.length > 300) throw bad('Bio : 300 caractères maximum');
    run('UPDATE users SET name = ?, city = ?, bio = ?, age = ? WHERE id = ?', name.trim(), String(city).trim(), bio, age, user.id);
    return { user: me_(one('SELECT * FROM users WHERE id = ?', user.id)) };
  });

  route('DELETE', '/account', ({ user }) => {
    run('DELETE FROM users WHERE demo_for = ?', user.id);
    run('DELETE FROM users WHERE id = ?', user.id);
    return { deleted: true };
  });

  route('GET', '/questions', () => ({ questions: questions.map(({ id, dim, text, options, maxChoices, key }) => ({ id, dim, text, options, maxChoices, key })) }));

  route('POST', '/answers', ({ user, body }) => {
    const v = validateAnswers(body.answers);
    if (!v.ok) throw bad(v.error);
    const up = db.prepare('INSERT INTO answers (user_id, question_id, selected) VALUES (?,?,?) ON CONFLICT(user_id, question_id) DO UPDATE SET selected = excluded.selected');
    db.exec('BEGIN');
    try {
      for (const [qid, sel] of Object.entries(v.answers)) up.run(user.id, Number(qid), JSON.stringify(sel));
      const all = answersOf(user.id);
      run('UPDATE users SET completed = ? WHERE id = ?', isComplete(all) ? 1 : 0, user.id);
      db.exec('COMMIT');
    } catch (e) { db.exec('ROLLBACK'); throw e; }
    const all = answersOf(user.id);
    return { completed: isComplete(all), answered: Object.keys(all).length, traits: buildTraits(all) };
  });

  route('POST', '/compatibility/analyze', ({ user }) => {
    if (!user.completed) throw new HttpError(409, 'Termine d\'abord le questionnaire');
    const spawned = demo ? spawnDemo(user) : 0;
    const count = matchesFor(user).length;
    notify(user.id, count ? `NEXA a trouvé ${count} personne(s) compatible(s) avec toi.` : `NEXA continue de chercher : aucune personne ≥ ${threshold} % pour l'instant.`);
    return { traits: buildTraits(answersOf(user.id)), matches: count, demoProfilesCreated: spawned };
  });

  const present = (m, idx, me) => {
    const locked = idx >= FREE_VISIBLE && !me.premium;
    if (locked) return { locked: true, score: m.score };
    return { locked: false, score: m.score, user: pub(m.user), dims: m.dims, reasons: m.reasons, warnings: m.warnings };
  };

  route('GET', '/matches', ({ user }) => {
    if (!user.completed) throw new HttpError(409, 'Termine d\'abord le questionnaire');
    const list = matchesFor(user);
    return { threshold, matches: list.map((m, i) => present(m, i, user)) };
  });

  route('GET', '/matches/:id', ({ user, params }) => {
    const list = matchesFor(user);
    const i = list.findIndex((m) => m.user.id === Number(params.id));
    if (i < 0) throw new HttpError(404, 'Ce profil ne fait pas partie de tes compatibilités');
    if (i >= FREE_VISIBLE && !user.premium) throw new HttpError(402, 'Profil réservé aux abonnés Premium', { code: 'premium_required' });
    const conn = one('SELECT * FROM connections WHERE (from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)', user.id, list[i].user.id, list[i].user.id, user.id);
    return { ...present(list[i], i, user), connection: conn ? { id: conn.id, status: conn.status, mine: conn.from_id === user.id } : null };
  });

  route('POST', '/connections/:userId', ({ user, params }) => {
    const target = Number(params.userId);
    const list = matchesFor(user);
    const i = list.findIndex((m) => m.user.id === target);
    if (i < 0) throw new HttpError(403, 'Tu ne peux contacter que tes compatibilités (≥ 80 %)');
    if (i >= FREE_VISIBLE && !user.premium) throw new HttpError(402, 'Profil réservé aux abonnés Premium', { code: 'premium_required' });
    if (isBlocked(user.id, target)) throw new HttpError(403, 'Action impossible');
    if (one('SELECT 1 x FROM connections WHERE (from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)', user.id, target, target, user.id)) {
      throw new HttpError(409, 'Une demande existe déjà avec cette personne');
    }
    const m = list[i];
    const r = run('INSERT INTO connections (from_id, to_id, score) VALUES (?,?,?)', user.id, target, m.score);
    const id = Number(r.lastInsertRowid);
    notify(target, `Quelqu'un souhaite faire connaissance avec toi. Compatibilité : ${m.score} %.`);
    if (demo && m.user.is_demo) { // acceptation automatique des profils simulés
      run("UPDATE connections SET status = 'accepted' WHERE id = ?", id);
      run('INSERT INTO messages (connection_id, sender_id, text) VALUES (?,?,?)', id, target, DEMO_REPLIES[0]);
      notify(user.id, `${m.user.name} a accepté ta demande. La conversation est ouverte.`);
    }
    return [201, { id, status: one('SELECT status FROM connections WHERE id = ?', id).status }];
  });

  route('GET', '/connections/incoming', ({ user }) => ({
    requests: q(`SELECT c.id, c.score, c.created_at, u.id uid, u.name, u.age, u.city, u.bio FROM connections c
      JOIN users u ON u.id = c.from_id WHERE c.to_id = ? AND c.status = 'pending' ORDER BY c.id DESC`, user.id)
      .map((r) => ({ id: r.id, score: r.score, createdAt: r.created_at, user: { id: r.uid, name: r.name, age: r.age, city: r.city, bio: r.bio } })),
  }));

  const decide = (status) => ({ user, params }) => {
    const c = one('SELECT * FROM connections WHERE id = ?', Number(params.id));
    if (!c || c.to_id !== user.id) throw new HttpError(404, 'Demande introuvable');
    if (c.status !== 'pending') throw new HttpError(409, 'Demande déjà traitée');
    run('UPDATE connections SET status = ? WHERE id = ?', status, c.id);
    if (status === 'accepted') notify(c.from_id, `${user.name} a accepté ta demande. La conversation est ouverte.`);
    return { id: c.id, status };
  };
  route('POST', '/connections/:id/accept', decide('accepted'));
  route('POST', '/connections/:id/reject', decide('rejected'));

  route('GET', '/conversations', ({ user }) => ({
    conversations: q("SELECT * FROM connections WHERE status = 'accepted' AND (from_id = ? OR to_id = ?) ORDER BY id DESC", user.id, user.id).map((c) => {
      const other = one('SELECT * FROM users WHERE id = ?', c.from_id === user.id ? c.to_id : c.from_id);
      const last = one('SELECT text, created_at, sender_id FROM messages WHERE connection_id = ? ORDER BY id DESC LIMIT 1', c.id);
      const n = one('SELECT COUNT(*) n FROM messages WHERE connection_id = ?', c.id).n;
      return { id: c.id, score: c.score, user: pub(other), lastMessage: last ? last.text : null, messageCount: n };
    }),
  }));

  route('GET', '/conversations/:id/messages', ({ user, params, query }) => {
    const c = connectionFor(user.id, Number(params.id));
    if (c.status !== 'accepted') throw new HttpError(403, 'Conversation non ouverte');
    const after = Number(query.get('after') || 0);
    const msgs = q('SELECT id, sender_id, text, created_at FROM messages WHERE connection_id = ? AND id > ? ORDER BY id', c.id, after)
      .map((m) => ({ id: m.id, mine: m.sender_id === user.id, text: m.text, createdAt: m.created_at }));
    const n = one('SELECT COUNT(*) n FROM messages WHERE connection_id = ?', c.id).n;
    const other = one('SELECT premium FROM users WHERE id = ?', c.from_id === user.id ? c.to_id : c.from_id);
    return { messages: msgs, total: n, freeLimit: FREE_MESSAGES, canSend: !!(user.premium || other.premium) || n < FREE_MESSAGES };
  });

  route('POST', '/conversations/:id/messages', ({ user, params, body }) => {
    const c = connectionFor(user.id, Number(params.id));
    if (c.status !== 'accepted') throw new HttpError(403, 'Conversation non ouverte');
    const text = typeof body.text === 'string' ? body.text.trim() : '';
    if (!text || text.length > 1000) throw bad('Message vide ou trop long (1000 caractères max)');
    const otherId = c.from_id === user.id ? c.to_id : c.from_id;
    const other = one('SELECT * FROM users WHERE id = ?', otherId);
    const n = one('SELECT COUNT(*) n FROM messages WHERE connection_id = ?', c.id).n;
    if (n >= FREE_MESSAGES && !user.premium && !other.premium) {
      throw new HttpError(402, 'Vous avez beaucoup de choses à vous dire ❤️ Passez en Premium pour continuer votre conversation.', { code: 'premium_required' });
    }
    const r = run('INSERT INTO messages (connection_id, sender_id, text) VALUES (?,?,?)', c.id, user.id, text);
    if (demo && other.is_demo) run('INSERT INTO messages (connection_id, sender_id, text) VALUES (?,?,?)', c.id, otherId, DEMO_REPLIES[1 + (n % (DEMO_REPLIES.length - 1))]);
    else notify(otherId, `Nouveau message de ${user.name}.`);
    return [201, { id: Number(r.lastInsertRowid) }];
  });

  route('GET', '/notifications', ({ user }) => ({
    notifications: q('SELECT id, text, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50', user.id)
      .map((n) => ({ id: n.id, text: n.text, read: !!n.is_read, createdAt: n.created_at })),
  }));
  route('POST', '/notifications/read', ({ user }) => { run('UPDATE notifications SET is_read = 1 WHERE user_id = ?', user.id); return { ok: true }; });

  route('GET', '/subscription', ({ user }) => ({ premium: !!user.premium, plan: user.premium ? 'premium' : 'free' }));
  route('POST', '/subscription', ({ user }) => {
    // TODO production : paiement réel (Konnect / Paymee / achat intégré) avant d'activer Premium.
    if (!fakePayment) throw new HttpError(501, 'Paiement non configuré');
    run('UPDATE users SET premium = 1 WHERE id = ?', user.id);
    return { premium: true };
  });

  route('POST', '/blocks', ({ user, body }) => {
    const t = Number(body.userId);
    if (!one('SELECT 1 x FROM users WHERE id = ?', t) || t === user.id) throw bad('Utilisateur invalide');
    run('INSERT OR IGNORE INTO blocks (user_id, blocked_id) VALUES (?,?)', user.id, t);
    run("UPDATE connections SET status = 'blocked' WHERE (from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)", user.id, t, t, user.id);
    return { blocked: true };
  });
  route('POST', '/reports', ({ user, body }) => {
    const t = Number(body.userId);
    if (!one('SELECT 1 x FROM users WHERE id = ?', t) || t === user.id) throw bad('Utilisateur invalide');
    if (typeof body.reason !== 'string' || !body.reason.trim()) throw bad('Motif obligatoire');
    run('INSERT INTO reports (reporter_id, reported_id, reason) VALUES (?,?,?)', user.id, t, body.reason.slice(0, 500));
    return [201, { reported: true }];
  });

  // ------------------------------------------------------------ HTTP
  const server = http.createServer(async (req, res) => {
    const send = (status, data) => {
      res.writeHead(status, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      });
      res.end(JSON.stringify(data));
    };
    try {
      if (req.method === 'OPTIONS') return send(204, {});
      const url = new URL(req.url, 'http://localhost');
      let body = {};
      if (req.method === 'POST' || req.method === 'PUT') {
        const chunks = []; let size = 0;
        for await (const c of req) { size += c.length; if (size > 1e6) throw new HttpError(413, 'Requête trop grande'); chunks.push(c); }
        const raw = Buffer.concat(chunks).toString();
        if (raw) { try { body = JSON.parse(raw); } catch { throw bad('JSON invalide'); } }
      }
      if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-cache' });
        return res.end(fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public', 'index.html')));
      }
      const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
      if (!r) throw new HttpError(404, 'Route inconnue');
      const params = url.pathname.match(r.re).groups || {};
      let user = null;
      if (r.auth) {
        const t = (req.headers.authorization || '').replace(/^Bearer /, '');
        const p = verify(t);
        user = p && one('SELECT * FROM users WHERE id = ?', p.uid);
        if (!user) throw new HttpError(401, 'Non authentifié');
      }
      const out = await r.handler({ req, body, params, query: url.searchParams, user, ip: req.socket.remoteAddress });
      Array.isArray(out) ? send(out[0], out[1]) : send(200, out);
    } catch (e) {
      if (e instanceof HttpError) return send(e.status, { error: e.message, ...e.extra });
      console.error(e);
      send(500, { error: 'Erreur serveur' });
    }
  });
  server.on('close', () => db.close());
  return server;
}
