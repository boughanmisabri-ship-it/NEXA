import assert from 'node:assert/strict';
import { buildApp } from '../src/server.js';
import { questions } from '../src/questions.js';
import { computeMatch, buildTraits, isComplete } from '../src/engine.js';

// --- Tests moteur ---------------------------------------------------------
const base = {};
for (const q of questions) base[q.id] = q.maxChoices > 0 ? [0, 1].slice(0, Math.min(2, q.maxChoices)) : [0];
base[47] = [];
assert.ok(isComplete(base), 'réponses complètes');
const same = computeMatch(base, base);
assert.equal(same.score, 100, 'identiques = 100 %');
assert.equal(Object.keys(buildTraits(base)).length, 10, '10 axes');

const noKids = structuredClone(base); noKids[31] = [4];          // "Non" aux enfants
const capped = computeMatch(base, noKids);
assert.ok(capped.score <= 60 && capped.warnings.length > 0, 'plafond enfants');

const db1 = structuredClone(base); db1[47] = [8];                  // deal-breaker : refus d'enfants
const blocked = computeMatch(db1, noKids);
assert.ok(blocked.blocks.includes("Refus d'avoir des enfants"), 'deal-breaker déclenché');
console.log('✓ moteur');

// --- Tests API ------------------------------------------------------------
const server = buildApp({ dbFile: ':memory:', demo: true, secret: 'test' });
await new Promise((r) => server.listen(0, r));
const url = `http://127.0.0.1:${server.address().port}`;
const call = async (method, path, body, token) => {
  const r = await fetch(url + path, {
    method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: r.status, data: await r.json() };
};

assert.equal((await call('GET', '/health')).status, 200);
assert.equal((await call('GET', '/profile')).status, 401, 'auth requise');

const reg = await call('POST', '/auth/register', { phone: '+21620123456', password: 'motdepasse1', name: 'Sarah', age: 27, city: 'Tunis', gender: 'Femme', lookingFor: 'Un homme' });
assert.equal(reg.status, 201);
const tok = reg.data.token;
assert.equal((await call('POST', '/auth/register', { phone: '+21620123456', password: 'motdepasse1', name: 'X', age: 27, city: 'Tunis', gender: 'Femme', lookingFor: 'Un homme' })).status, 409, 'doublon');
assert.equal((await call('POST', '/auth/register', { phone: '+21620999999', password: 'motdepasse1', name: 'Mineur', age: 16, city: 'Tunis', gender: 'Femme', lookingFor: 'Un homme' })).status, 400, 'mineur refusé');
assert.equal((await call('POST', '/auth/login', { phone: '+21620123456', password: 'faux' })).status, 401);
assert.equal((await call('POST', '/auth/login', { phone: '+21620123456', password: 'motdepasse1' })).status, 200);

const qs = await call('GET', '/questions', null, tok);
assert.equal(qs.data.questions.length, 50);
assert.equal((await call('GET', '/matches', null, tok)).status, 409, 'questionnaire requis');

const bad = await call('POST', '/answers', { answers: { 1: [99] } }, tok);
assert.equal(bad.status, 400, 'réponse invalide refusée');

const mine = {};
for (const q of questions) mine[q.id] = q.maxChoices > 0 ? [0, 1, 2].slice(0, Math.min(3, q.maxChoices)) : [q.id % q.options.length];
mine[47] = [];
const ans = await call('POST', '/answers', { answers: mine }, tok);
assert.equal(ans.status, 200);
assert.equal(ans.data.completed, true);

const an = await call('POST', '/compatibility/analyze', null, tok);
assert.equal(an.status, 200);
assert.equal(an.data.demoProfilesCreated, 8);
assert.ok(an.data.matches >= 3, `au moins 3 matchs (obtenu ${an.data.matches})`);

const m = await call('GET', '/matches', null, tok);
const list = m.data.matches;
console.log('  scores :', list.map((x) => (x.locked ? '🔒' : x.user.name) + ' ' + x.score + '%').join(' | '));
assert.ok(list.every((x) => x.score >= 80), 'seuil 80 %');
assert.ok(list.length <= 5);
assert.ok(list.slice(3).every((x) => x.locked), 'profils 4-5 masqués en gratuit');
assert.deepEqual([...list].map((x) => x.score), [...list].map((x) => x.score).sort((a, b) => b - a), 'tri décroissant');

const top = list[0];
const det = await call('GET', `/matches/${top.user.id}`, null, tok);
assert.equal(det.status, 200);
assert.equal(det.data.reasons.length, 3);

// Demande de connexion + acceptation auto (démo)
const con = await call('POST', `/connections/${top.user.id}`, null, tok);
assert.equal(con.status, 201);
assert.equal(con.data.status, 'accepted');
assert.equal((await call('POST', `/connections/${top.user.id}`, null, tok)).status, 409, 'doublon refusé');
assert.equal((await call('POST', '/connections/9999', null, tok)).status, 403, 'hors compatibilité refusé');
if (list.length > 3 && list[3].locked) {
  assert.equal((await call('GET', `/conversations`, null, tok)).data.conversations.length, 1);
}

// Chat : 50 messages gratuits
const convId = con.data.id;
let sent = 0, blockedAt = null;
for (let i = 0; i < 60; i++) {
  const r = await call('POST', `/conversations/${convId}/messages`, { text: `msg ${i}` }, tok);
  if (r.status === 402) { blockedAt = (await call('GET', `/conversations/${convId}/messages`, null, tok)).data.total; break; }
  assert.equal(r.status, 201); sent++;
}
assert.ok(blockedAt >= 50 && blockedAt <= 51, 'blocage à 50 messages (+1 réponse démo possible)');
const st = await call('GET', `/conversations/${convId}/messages`, null, tok);
assert.equal(st.data.canSend, false);
assert.equal((await call('POST', '/subscription', null, tok)).data.premium, true);
assert.equal((await call('POST', `/conversations/${convId}/messages`, { text: 'merci Premium' }, tok)).status, 201, 'Premium débloque le chat');
const m2 = await call('GET', '/matches', null, tok);
assert.ok(m2.data.matches.every((x) => !x.locked), 'Premium voit tous les profils');

// Notifications, signalement, blocage, isolation entre utilisateurs
assert.ok((await call('GET', '/notifications', null, tok)).data.notifications.length >= 2);
assert.equal((await call('POST', '/reports', { userId: top.user.id, reason: 'faux profil' }, tok)).status, 201);
const reg2 = await call('POST', '/auth/register', { phone: '+21620765432', password: 'motdepasse2', name: 'Amine', age: 30, city: 'Sfax', gender: 'Homme', lookingFor: 'Une femme' }, null);
assert.equal((await call('GET', `/conversations/${convId}/messages`, null, reg2.data.token)).status, 404, 'conversation privée');
assert.equal((await call('POST', '/blocks', { userId: top.user.id }, tok)).status, 200);
const m3 = await call('GET', '/matches', null, tok);
assert.ok(!m3.data.matches.some((x) => x.user && x.user.id === top.user.id), 'profil bloqué disparaît');

// Suppression de compte
assert.equal((await call('DELETE', '/account', null, tok)).status, 200);
assert.equal((await call('GET', '/profile', null, tok)).status, 401);

server.close();
console.log('✓ API : tous les tests passent');
